<template>
  <div>
    <users/>
  </div>
</template>
<script>
import users from './Views/users.vue'
export default {
  components: {
    users
  }
}
</script>